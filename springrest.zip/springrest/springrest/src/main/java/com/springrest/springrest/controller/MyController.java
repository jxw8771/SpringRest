package com.springrest.springrest.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.springrest.springrest.services.BillService;

@RestController
public class MyController {

	@Autowired
	private BillService billService;
	@GetMapping("/home")
	public String home()
	{
	return "home";	
	}
	
	@GetMapping("/home/{bill}")
	public String getDetails(@PathVariable String bill)
	{
		return this.billService.getDetails(Integer.parseInt(bill));
	}
}
