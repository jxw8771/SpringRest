package com.springrest.springrest.services;

import org.springframework.stereotype.Service;

@Service
public class BillImplementation implements BillService{

	@Override
	public String getDetails(int bill) {
		// TODO Auto-generated method stub
		
		float[] coins= {0.01f,0.05f, 0.10f,0.25f};
		int[] limit= {100,100,100,100}; 
		int k=0;
		String content=null;
		boolean flag=false;
		for(int i=coins.length-1;i>=0;i--)
		{
			if(limit[i]==0)
				continue;
			k=(int) (bill/coins[i]);
			if(k<limit[i])
			{
				content=content + "Coins are of type "+coins[i]+" and quantity "+k;
				limit[i]=limit[i]-k;
				flag=true;
				break;
			}
			else
			{
				bill=(int) (bill- (coins[i]*limit[i]));
				content=content + "Coins are of type "+coins[i]+" and quantity "+limit[i];
				limit[i]=0;
			}
			
		}
			if(flag==true)
				return content;
			else
				return "Not Enough coins";
			
		
	}

}
