package com.springrest.springrest.services;

public interface BillService {

	String getDetails(int bill);

}
